import React from "react";

const Header = () => (
  <header className="App-header">
    <h1 className="App-title">Recipe Search</h1>
  </header>
);

export default Header;
