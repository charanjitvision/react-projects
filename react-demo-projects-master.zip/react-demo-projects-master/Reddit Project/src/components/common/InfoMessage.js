import React from 'react';

const InfoMessage = ({ children }) => {
  return <p>{children}</p>;
};

export default InfoMessage;
