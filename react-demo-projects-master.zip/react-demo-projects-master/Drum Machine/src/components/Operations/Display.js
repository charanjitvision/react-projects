import React from "react";

import "../../App.css";

const Display = props => {
  return <p id="display">{props.display}</p>;
};

export default Display;
