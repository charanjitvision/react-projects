import React from "react";

const Dashhboard = () => {
  return <div>Dashboard</div>;
};

export default Dashhboard;
